<?php
?>
</main>
<footer class="site-footer">
  <div class="container">
    <small>&copy; <?= date('Y') ?> Event Horizon - Developed by Karlo Siric | All rights reserved</small>
  </div>
</footer>
</body>
</html>
